


export class Employee{
    empId:number;
    employeeName:string;
    employeePrice:number;
    employeeDescription:string;
}